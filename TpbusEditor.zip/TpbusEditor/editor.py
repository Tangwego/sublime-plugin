#coding=utf-8
# _*_ coding:utf-8 _*_
import sublime, sublime_plugin
import platform
import sys,os
import subprocess

DEF_JAVA_CMD = "D:\\Program Files\\Java\\jdk1.8.0_181\\bin\\java.exe"
DEF_TPBUS_EDITOR = "\"D:\\Program Files\\Sublime Text\\Data\\Packages\\TpbusEditor\\"
#TPBUS_EDITOR = "\"" + sublime.installed_packages_path() + "\\Tpbus Editor\\"
#TPBUS_EDITOR = "\"" + os.curdir + "/"
DEF_JAVA_OPTION = " "

def load():
    print("load profile.")
    global JAVA_CMD
    global TPBUS_EDITOR
    global JAVA_OPTION
    settings_path = sublime.packages_path() + "\\User\\TpbusEditor.sublime-settings"
    print(settings_path)
    if(os.path.exists(settings_path)) is False:
        prof = ''' {
                "java_cmd": "java",
                "java_opt": "",
                "ssh_client_path":"./"
                } '''
        file = open(settings_path,'w')
        file.write(prof)
        file.close()
    settings = sublime.load_settings(settings_path)
    JAVA_CMD = settings.get('java_cmd',DEF_JAVA_CMD)
    TPBUS_EDITOR = settings.get('java_opt',DEF_TPBUS_EDITOR)
    JAVA_OPTION = settings.get('ssh_client_path',DEF_JAVA_OPTION)
    print("java home:",JAVA_CMD)
    print("java option:",JAVA_OPTION)
    print("editor home:",TPBUS_EDITOR)
    if JAVA_CMD in sys.path:
        pass
    else:
        sys.path.append(JAVA_CMD)
    if TPBUS_EDITOR in sys.path:
        pass
    else:
        sys.path.append(TPBUS_EDITOR)

class UploadCommand(sublime_plugin.TextCommand):

    def run(self, edit):
        load()
        print("上传TPBUS脚本...")
        file_path = self.view.file_name()
        print("文件路径: " + str(file_path))
        try:
            if os.path.isfile(file_path) is True:
                remote_path, file_name = os.path.split(file_path)
                print("文件名：[" + file_name + "]")
                remote_path = remote_path.replace("E:\\tpbus","").replace("\\","/")
                if remote_path.startswith("/") is False:
                    remote_path = "/" + remote_path
                if remote_path.endswith("/") is False:
                    remote_path = remote_path + "/"
                print("远程目录: [" + remote_path + "]")
                cfg_path = "/home/tpbus/conf/heb/config"
                cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" put " + file_path + " " + cfg_path + remote_path + JAVA_OPTION
                print("执行命令:" + cmd)
                result = os.popen(cmd)
                print("结果:" + str(result.read()))
                sublime.message_dialog("上传" + file_name + "成功")
                #sublime.ok_cancel_dialog("上传" + file_name + "成功", "确定")
                ## TODO
            else:
                ## TODO
                sublime.message_dialog("不能上传目录!")
        except Exception as e:
            sublime.message_dialog("文件不存在！\n" + str(e))

class DownloadCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        #print(sys.path)
        print("下载TPBUS配置文件...")
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" get" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = os.system(cmd)
        print("结果:" + str(result))
        sublime.message_dialog("下载完成！")

class RestartCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        print("重新启动TPBUS...")
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" exec \". ~/conf/tpbus.env; tpbus kill; tpbus start\"" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = os.popen(cmd).read()
        print(str(result))
        sublime.message_dialog("TPBUS重启完成\n" + str(result))

class ReloadCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        print("重新加载TPBUS...")
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" exec \". ~/conf/tpbus.env; reload\"" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = subprocess.Popen(cmd,shell=True, 
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        stdout, stderr = result.communicate(input=None)
        sublime.message_dialog("TPBUS重新加载完成:\n" + bytes(stdout).decode('utf8',"ignore"))

class StatusCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" exec \". ~/conf/tpbus.env; tpbus status\"" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = os.popen(cmd).read()
        print(str(result))
        sublime.message_dialog("TPBUS状态:\n" + str(result))

class TaskCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" exec \". ~/conf/tpbus.env; tt\"" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = subprocess.Popen(cmd,shell=True, 
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        stdout, stderr = result.communicate(input=None)
        sublime.message_dialog("TPBUS任务列表:\n" + bytes(stdout).decode('utf8',"ignore"))

class KillCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" exec \". ~/conf/tpbus.env; tpbus kill\"" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = subprocess.Popen(cmd,shell=True, 
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        stdout, stderr = result.communicate(input=None)
        sublime.message_dialog("TPBUS任务列表:\n" + bytes(stdout).decode('utf8',"ignore"))

class StartCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        load()
        cmd = "java -jar " + TPBUS_EDITOR + "SSHClient.jar\" exec \". ~/conf/tpbus.env; tpbus start\"" + JAVA_OPTION
        print("执行命令: " + cmd)
        result = subprocess.Popen(cmd,shell=True, 
                                        stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        stdout, stderr = result.communicate(input=None)
        sublime.message_dialog("TPBUS任务列表:\n" + bytes(stdout).decode('utf8',"ignore"))

class SaveAndUploadCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        print("保存并上传！")
        self.view.run_command('save')
        #retcode = sublime.ok_cancel_dialog("是否上传？","确定")
        #if retcode is True:
        #    self.view.run_command('upload')
        #else:
        #    print("未上传文件")